<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Storage;


class UsersController extends Controller
{
    public function __invoke(){
        $role = Role::all();
        return view('users', compact('role'));
    }

     public function store(Request $request)
    {    
        $validator = $request->validate([
            'email' => 'required|string|email|max:255|unique:users,email', 
        ]);
        
        if ($validator instanceof \Illuminate\Contracts\Validation\Validator) {
            if ($validator->fails()) {
                return response()->json($validator->messages(), Response::HTTP_BAD_REQUEST);
            }
        } else {
            $imageName = null;
            if ($request->hasFile('profile')) {
                $image = $request->file('profile');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $directory = 'uploads/profile_images';
                $image->move(public_path($directory), $imageName);
            }

            // Create new user
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'description' => $request->description,
                'role_id' => $request->role_id,
                'profile_image' => $imageName,
            ]);

            return response()->json(['message' => 'User created successfully', 'user' => $user]);
                }
        }

        public function userList(){
            $users = User::with('role')->orderBy('id', 'desc')->get();
            $usersList =[];

            foreach($users as $key => $user){
                $profileImage = $user->profile_image ? $user->profile_image : 'images.jpeg';
                $img = asset('/uploads/profile_images').'/'. $profileImage; 
                $usersList[] =[
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'phone' => $user->phone,
                    'role_name' => $user->role->name, // Assuming 'name' is the role name
                    'profile_image' => $img
                ];
            } 
            return response()->json($usersList);
        }
}
