<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
  <title>Demo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
       <style>
    .error
    {
     color:#FF0000;
    }
    </style>
</head>
<body>
  <div class="container py-5">
  <h4>ADD USER</h4>

  <form id="userForm" enctype='multipart/form-data'>
    <div class="row">
      <div class="col-lg-4 col-12"> 
        <div class="form-group">
          <label for="name">Name</label>
          <input type="name" class="form-control" placeholder="Enter name" id="name" name="name">
        </div>
      </div>
      <div class="col-lg-4 col-12"> 
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" placeholder="Enter email" name="email" id="email">
        <span id="email_error" class="error" for="email"></span>
      </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="form-group">
          <label for="phone">Phone:</label>
          <input type="phone" class="form-control" placeholder="Enter phone" id="phone" name="phone">
        </div>
      </div>
      <div class="col-lg-6 col-12"> 
        <div class="form-group">
          <label for="role_id">Role ID</label>
          <select class="form-control" id="role_id" name="role_id">
            <option value="">Select Role Name</option>
            @foreach($role as $key => $val)
            <option value="{{$val->id}}">{{$val->name}}</option>
            @endforeach
          </select>
        </div>
      </div>
      <div class="col-lg-6 col-12"> 
      <div class="form-group">
        <label for="email">Profile Image</label>
        <input type="file" class="form-control" placeholder="Enter email" name="profile" id="profile">
      </div>
      </div>
      <div class="col-lg-12 col-12">
        <div class="form-group">
          <label for="phone">Description</label>
          <textarea type="text" name="description" class="form-control" placeholder="Enter description" id="description"></textarea>
        </div>
      </div>


    </div>
  <button type="submit" class="btn btn-success font-weight-bold">Submit</button>
</form>


<!-- users list here -->
    <section>
      <div class="py-3 mt-4">
        <h5>USERS LIST</h5>
      </div>
      <table class="table table-hover" id="userDataTable">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col">Role Name</th>
              <th scope="col">Profile Image</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
        </table>
    </section>
</div>
@include('ajax')
</body>
</html>

