
<script>
    $(document).ready(function() {
        if($("#userForm").length > 0){
        $('#userForm').validate({
            rules: {
                name: {
                    required: true
                },
                email: {
                    required: true,
                    email: true
                },
                phone: {
                    required: true,
                    phoneIN: true
                },
                role_id: {
                    required: true
                },
                description: {
                    required: true
                }
            },
            messages: {
                name: {
                    required: "Please enter your name"
                },
                email: {
                    required: "Please enter your email",
                    email: "Please enter a valid email address"
                },
                phone: {
                    required: "Please enter your phone number",
                    phoneIN: "Please enter a valid Indian phone number"
                },
                role_id: {
                    required: "Please select a role"
                },
                description: {
                    required: "Please enter a description"
                }
            },
            submitHandler: function (form) {
              var submitButton = $(form).find('button[type="submit"]');
              submitButton.prop('disabled', true).html('Please wait...');
            
              var email_error = $('#email_error');

            var formData = new FormData(form);
            $.ajax({
                url: '/api/add-user', // Replace with your API endpoint
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                  fetchUsers();
                  email_error.html(''); 
                  email_error.css('display', 'none');
                  console.log(response);
                  $(form)[0].reset();
                  submitButton.prop('disabled', false).html('Submit');
                },
                error: function(error) {
                  var response = JSON.parse(error.responseText);
                  if (response.errors) {
                      email_error.css('display', 'block');
                      email_error.html(response.errors['email'][0]); 
                  } else {
                      alert('Error creating user.');
                  } 
                  submitButton.prop('disabled', false).html('Submit');
                }
            });
        }
        }); 

        
        $.validator.addMethod("phoneIN", function(phone_number, element) {
            phone_number = phone_number.replace(/\s+/g, "");
            return this.optional(element) || phone_number.length > 9 &&
                phone_number.match(/^[0-9]{10}$/);
        }, "Please specify a valid phone number");
         // Custom method to validate Indian phone numbers
        $.validator.addMethod("phoneIN", function(phone_number, element) {
            phone_number = phone_number.replace(/\s+/g, "");
            return this.optional(element) || phone_number.length > 9 &&
                phone_number.match(/^[0-9]{10}$/);
        }, "Please specify a valid phone number");
    }


    function fetchUsers() {
        $.ajax({
            url: '/api/get-users',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#userDataTable tbody');
                if(data ==''){
                    tbody.append("No users found");
                }else{
                    tbody.empty();
                    $.each(data, function(index, item) {
                        var row = $('<tr>').append(
                            $('<th>').attr('scope', 'row').text(index + 1),
                            $('<td>').text(item.name),
                            $('<td>').text(item.email),
                            $('<td>').text(item.phone),
                            $('<td>').text(item.role_name),
                            $('<td>').html('<img src="' + item.profile_image + '" alt="Profile Image" width="50" height="50">')
                        );
                        tbody.append(row);
                    });
                }
            },
            error: function() {
                console.error('Failed to fetch data.');
            }
        });
    }

fetchUsers();

    });
</script><?php /**PATH /var/www/html/demo/resources/views/ajax.blade.php ENDPATH**/ ?>